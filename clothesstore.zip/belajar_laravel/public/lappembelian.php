<html>
<head>
	<title>Laporan Pembelian</title>
</head>
<body>
 
	<center>
 
		<h2>DATA LAPORAN PEMBELIAN BARANG</h2>
		<h4>CLOTESTORE</h4>
 
	</center>
 
	<?php 
	include 'koneksi.php';
	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">Id Pembelian</th>
			<th>Tanggal Beli</th>
			<th>Nama Supplier</th>
			<th>Nama Barang</th>
			<th>Kategori</th>
			<th>Harga Beli</th>
			<th width="5%">Qty</th>
			<th>Total</th>
		</tr>
		<?php 
		$id_pembelian = 1;
		$sql = mysqli_query($koneksi,"SELECT pembelian.id_pembelian,pembelian.tgl_beli, supplier.nama_supplier, barang.nama_brg, pembelian.qty,pembelian.kategori, pembelian.harga_beli, pembelian.total,SUM(pembelian.total) as subtotal FROM pembelian JOIN supplier ON pembelian.id_supplier = supplier.id_supplier JOIN barang ON pembelian.id_barang=barang.id_barang;");
		while($data = mysqli_fetch_array($sql)){
		?>
		<tr>
			<td><?php echo $id_pembelian++; ?></td>
      		<td><?php echo $data['tgl_beli']; ?></td>
      		<td><?php echo $data['nama_supplier']; ?></td>
      		<td><?php echo $data['nama_brg']; ?></td>
      		<td><?php echo $data['kategori']; ?></td>
      		<td><?php echo number_format($data['harga_beli']); ?></td>
      		<td><?php echo $data['qty']; ?></td>
      		<td><?php echo number_format($data['total']); ?></td>
		</tr>
		<tr>
			<td colspan="7">Subtotal</td>
			<td><?php echo number_format($data['subtotal']); ?></td>
		</tr>
		<?php } ?>		
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>