<?php
	include "koneksi.php";

	$id = $_POST['id'];
    $nama_supplier = $_POST['nama_supplier'];
    $alamat_supplier = $_POST['alamat_supplier'];
    $telp_supplier = $_POST['telp_supplier'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO supplier VALUES ('$id', '$nama_supplier','$alamat_supplier','$telp_supplier')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: supplier.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
