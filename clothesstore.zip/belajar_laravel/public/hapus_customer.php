<?php
	include "koneksi.php";
 
	$id_customer = $_GET["id_customer"];
 
	// query sql
	$sql = "DELETE FROM customer WHERE id_customer='$id_customer'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error($koneksi));
 
	if($query){
		echo "Data berhasil di Hapus!";
		header('Location: customer.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}
 
	mysqli_close($koneksi);
?>