<?php
	include "koneksi.php";
 
	$id_penjualan = $_GET["id_penjualan"];
 
	// query sql
	$sql = "DELETE FROM penjualan WHERE id_penjualan='$id_penjualan'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error($koneksi));
 
	if($query){
		echo "Data berhasil di Hapus!";
		header('Location: penjualan.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}
 
	mysqli_close($koneksi);
?>