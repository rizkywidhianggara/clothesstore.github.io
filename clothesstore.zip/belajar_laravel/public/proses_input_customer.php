<?php
	include "koneksi.php";

	$id = $_POST['id'];
    $nama_customer = $_POST['nama_customer'];
    $alamat_customer = $_POST['alamat_customer'];
    $telp_customer = $_POST['telp_customer'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO customer VALUES ('$id', '$nama_customer','$alamat_customer','$telp_customer')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: customer.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
