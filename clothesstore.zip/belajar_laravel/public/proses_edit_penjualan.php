<?php
	include "koneksi.php";

	$id_penjualan = $_POST['id_penjualan'];
	$tgl_jual = $_POST['tgl_jual'];
    $id_customer= $_POST['id_customer'];
    $id_barang = $_POST['id_barang'];
    $kategori = $_POST['kategori'];
    $harga_jual = $_POST['harga_jual'];
    $qty = $_POST['qty'];
    $total = $_POST['total'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "UPDATE penjualan SET tgl_jual='$tgl_jual', id_customer='$id_customer', id_barang='$id_barang', kategori='$kategori', harga_jual='$harga_jual',qty='$qty',total='$total' WHERE id_penjualan='$id_penjualan'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

	if($query){
		echo "Data berhasil dirubah!";
		header('location: penjualan.php');
	} else {
		echo "Error".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>