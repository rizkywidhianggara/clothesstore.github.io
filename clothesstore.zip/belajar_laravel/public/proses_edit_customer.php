<?php
	include "koneksi.php";

	$id_customer = $_POST['id_customer'];
	$nama_customer = $_POST['nama_customer'];
	$alamat_customer = $_POST['alamat_customer'];
	$telp_customer = $_POST['telp_customer'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "UPDATE customer SET nama_customer='$nama_customer', alamat_customer='$alamat_customer',telp_customer='$telp_customer' WHERE id_customer='$id_customer'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

	if($query){
		echo "Data berhasil dirubah!";
		header('location: customer.php');
	} else {
		echo "Error".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>