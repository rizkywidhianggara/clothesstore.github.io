<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 
	<h1>Selamat Datang di ClothesStore<br/><h1>Silahkan Login dahulu</h1>
 
<div class="kotak_login">
<p class="tulisan_login">Silahkan login</p>
  <form class="form-control" action="proses_input_admin.php" method="post">
  	<div class="form-group">
    <label for="username">username</label>
    <input type="text" class="form-control" name="username">
  	</div>
  	<div class="form-group">
    <label for="password">password</label>
    <input type="text" class="form-control" name="password">
  	</div>
  	<input type="submit" class="btn btn-primary" value="Simpan" name="simpan">
  </form>
</div>

 
</body>
</html