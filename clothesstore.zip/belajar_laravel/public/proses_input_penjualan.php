<?php
	include "koneksi.php";
    $tgl_jual = $_POST['tgl_jual'];
    $id_customer= $_POST['id_customer'];
    $id_barang = $_POST['id_barang'];
    $kategori = $_POST['kategori'];
    $harga_jual = $_POST['harga_jual'];
    $qty = $_POST['qty'];
    $total = $_POST['total'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO penjualan VALUES ('', '$tgl_jual', '$id_customer','$id_barang','$kategori','$harga_jual','$qty','$total')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: penjualan.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
