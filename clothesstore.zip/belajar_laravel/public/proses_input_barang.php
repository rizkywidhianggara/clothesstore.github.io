<?php
	include "koneksi.php";


    $nama_brg = $_POST['nama_brg'];
    $kategori = $_POST['kategori'];
    $harga_beli = $_POST['harga_beli'];
    $harga_jual = $_POST['harga_jual'];
    $stok = $_POST['stok'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO barang VALUES ('', '$nama_brg','$kategori','$harga_beli','$harga_jual','$stok')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: barang.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
