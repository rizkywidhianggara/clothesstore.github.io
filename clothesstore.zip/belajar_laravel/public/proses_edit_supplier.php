<?php
	include "koneksi.php";

	$id_supplier = $_POST['id_supplier'];
	$nama_supplier = $_POST['nama_supplier'];
	$alamat_supplier = $_POST['alamat_supplier'];
	$telp_supplier = $_POST['telp_supplier'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "UPDATE supplier SET nama_supplier='$nama_supplier', alamat_supplier='$alamat_supplier',telp_supplier='$telp_supplier' WHERE id_supplier='$id_supplier'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

	if($query){
		echo "Data berhasil dirubah!";
		header('location: supplier.php');
	} else {
		echo "Error".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>