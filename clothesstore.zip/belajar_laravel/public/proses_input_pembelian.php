<?php
	include "koneksi.php";

    $tgl_beli = $_POST['tgl_beli'];
    $id_supplier= $_POST['id_supplier'];
    $id_barang = $_POST['id_barang'];
    $kategori = $_POST['kategori'];
    $harga_beli = $_POST['harga_beli'];
    $qty = $_POST['qty'];
    $total = $_POST['total'];


	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO pembelian VALUES (' ', '$tgl_beli', '$id_supplier', '$id_barang','$kategori','$harga_beli','$qty','$total')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: pembelian.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
