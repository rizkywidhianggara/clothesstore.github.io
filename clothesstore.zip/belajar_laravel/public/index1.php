<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <title>UAS</title>

    <link href="../assets/img/icon.jpg" rel="icon">
    <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    
  </head>
  <body>

  <nav class="navbar navbar-expand-md navbar-dark bg-dark"> 	
  <a class="navbar-brand" href="#">
    <img src="bootstrap.png" width="30" height="30" class="d-inline-block align-top" alt=""> ClothesStore</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index1.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Master
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="customer.php">Customer</a>
          <a class="dropdown-item" href="supplier.php">Supplier</a>
          <a class="dropdown-item" href="barang.php">Barang</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Transaksi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="pembelian.php">Pembelian</a>
          <a class="dropdown-item" href="penjualan.php">Penjualan</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin.php">Admin</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <button class="btn btn-danger square-btn-adjust" href="index.php" type="submit">Logout</button>
    </form>
  </div>
</nav>

<br>
<center><h3>Selamat Datang di ClothesStore</h3></center>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

  <main id="main">

    <!-- ======= Hoodies Section ======= -->
      <section id="produk" class="produk">
          <div class="container">
            <div class="section-title" data-aos="fade-up">
              <h2>Hoddies</h2>
              <p>Kami disini menjual berbagai macam Jaket Hoddies Original dari Brand H&M</p>
            </div>
            <div class="row team_inner">
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/hoodies/hoodie2.jpg" alt="">
                  </div>
                  <div>
                    <h4>Hooded Top With Motif</h4>
                    <p>IDR 400,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/hoodies/hoodie1.jpg" alt="">
                </div>
                  <div>
                    <h4>Hooded Top Black</h4>
                    <p>IDR 400,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/hoodies/hoddie3.jpg" alt="">
               </div>
                  <div>
                    <h4>Hooded Top</h4>
                    <p>IDR 400,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/hoodies/hoodie4.jpg" alt="">
                 </div>
                  <div >
                    <h4>Hooded Top With Motif</h4>
                    <p>IDR 400,000</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- End Hoodies Section -->

      <!-- ======= Shirt Section ======= -->
      <section id="produk" class="produk">
          <div class="container">
            <div class="section-title" data-aos="fade-up">
              <h2>Shirt</h2>
              <p>Kami disini juga menjual bermacam macam Kemeja Original dari Brand H&M</p>
            </div>
            <div class="row team_inner">
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="shirt_img">
                    <img class="img-fluid" src="../assets/img/shirt/shirt1.jpg" alt="">
                  </div>
                  <div>
                    <h4>Resort Shirt Regular Fit</h4>
                    <p>IDR 329,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/shirt/shirt2.jpg" alt="">
                </div>
                  <div>
                    <h4>Patterned Resort Shirt</h4>
                    <p>IDR 329,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/shirt/shirt3.jpg" alt="">
               </div>
                  <div>
                    <h4>Viscose Resort Shirt</h4>
                    <p>IDR 329,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/shirt/shirt4.jpg" alt="">
                 </div>
                  <div >
                    <h4>Short-Sleeved Cotton Shirt</h4>
                    <p>IDR 329,000</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- End Shirt Section -->

        <!-- ======= T-Shirt Section ======= -->
      <section id="produk" class="produk">
          <div class="container">
            <div class="section-title" data-aos="fade-up">
              <h2>T-Shirt</h2>
              <p>Kami disini juga menjual beraneka ragam Kaos Original dari Brand H&M</p>
            </div>
            <div class="row team_inner">
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="T-shirt_img">
                    <img class="img-fluid" src="../assets/img/T-shirt/t-shirt1.jpg" alt="">
                  </div>
                  <div>
                    <h4>Printed T-Shirt</h4>
                    <p>IDR 269,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/T-shirt/t-shirt2.jpg" alt="">
                </div>
                  <div>
                    <h4>Polo Shirt Slim Fit</h4>
                    <p>IDR 269,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/T-shirt/t-shirt3.jpg" alt="">
               </div>
                  <div>
                    <h4>Patterned Cotton T-Shirt</h4>
                    <p>IDR 269,000</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div>
                  <div class="hoodies_img">
                    <img class="img-fluid" src="../assets/img/T-shirt/t-shirt4.jpg" alt="">
                 </div>
                  <div >
                    <h4>Printed T-Shirt</h4>
                    <p>IDR 269,000</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- End T-Shirt Section -->

</body>
</html>