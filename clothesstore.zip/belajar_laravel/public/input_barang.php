<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>UAS</title>
    
  </head>
  <body>

  <nav class="navbar navbar-expand-md navbar-dark bg-dark"> 	
  <a class="navbar-brand" href="#">
    <img src="bootstrap.png" width="30" height="30" class="d-inline-block align-top" alt=""> ClothesStore</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index1.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Master
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="customer.php">Customer</a>
          <a class="dropdown-item" href="suplier.php">Supplier</a>
          <a class="dropdown-item" href="barang.php">Barang</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Transaksi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="pembelian.php">Pembelian</a>
          <a class="dropdown-item" href="penjualan.php">Penjualan</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin.php">Admin</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <button class="btn btn-danger square-btn-adjust" type="submit">Logout</button>
    </form>
  </div>
</nav>

<br>
<center><h3>Input Barang di ClothesStore</h3></center>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<div class="container">
  <form class="form-control" action="proses_input_barang.php" method="post">
  <div class="form-group">
    <label for="nama_pemain">Nama Barang</label>
    <input type="text" class="form-control" name="nama_brg">
  </div>
  <div class="form-group">
    <label for="kategori">Kategori</label>
    <select class="form-control" name="kategori">
      <option>Jaket</option>
      <option>Kemeja</option>
      <option>Kaos</option>
    </select>
  </div>
  <div class="form-group">
    <label for="harga_beli">Harga Beli</label>
    <input type="text" class="form-control" name="harga_beli">
  </div>
  <div class="form-group">
    <label for="harga_jual">Harga Jual</label>
    <input type="text" class="form-control" name="harga_jual">
  </div>
  <div class="form-group">
    <label for="stok">Stok</label>
    <input type="text" class="form-control" name="stok">
  </div>
  <input type="submit" class="btn btn-primary" value="Simpan" name="simpan">
</form>
</body>
</html>