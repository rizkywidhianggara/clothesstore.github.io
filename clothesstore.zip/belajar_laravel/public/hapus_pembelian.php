<?php
	include "koneksi.php";
 
	$id_pembelian = $_GET["id_pembelian"];
 
	// query sql
	$sql = "DELETE FROM pembelian WHERE id_pembelian='$id_pembelian'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error($koneksi));
 
	if($query){
		echo "Data berhasil di Hapus!";
		header('Location: pembelian.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}
 
	mysqli_close($koneksi);
?>