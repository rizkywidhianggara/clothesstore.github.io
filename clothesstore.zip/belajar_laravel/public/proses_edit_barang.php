<?php
	include "koneksi.php";

	$id_barang = $_POST['id_barang'];
	$nama_brg = $_POST['nama_brg'];
	$kategori = $_POST['kategori'];
	$harga_beli = $_POST['harga_beli'];
	$harga_jual = $_POST['harga_jual'];
	$stok = $_POST['stok'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "UPDATE barang SET nama_brg='$nama_brg', kategori='$kategori', harga_beli='$harga_beli',harga_jual='$harga_jual',stok='$stok' WHERE id_barang='$id_barang'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

	if($query){
		echo "Data berhasil dirubah!";
		header('location: barang.php');
	} else {
		echo "Error".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>