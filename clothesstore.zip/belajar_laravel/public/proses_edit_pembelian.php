<?php
	include "koneksi.php";

	$id_pembelian = $_POST['id_pembelian'];
	$tgl_beli = $_POST['tgl_beli'];
    $id_supplier= $_POST['id_supplier'];
    $id_barang = $_POST['id_barang'];
    $kategori = $_POST['kategori'];
    $harga_beli = $_POST['harga_beli'];
    $qty = $_POST['qty'];
    $total = $_POST['total'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "UPDATE pembelian SET tgl_beli='$tgl_beli', id_supplier='$id_supplier', id_barang='$id_barang', kategori='$kategori', harga_beli='$harga_beli',qty='$qty',total='$total' WHERE id_pembelian='$id_pembelian'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

	if($query){
		echo "Data berhasil dirubah!";
		header('location: pembelian.php');
	} else {
		echo "Error".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>