<?php
	include "koneksi.php";
 
	$id_supplier = $_GET["id_supplier"];
 
	// query sql
	$sql = "DELETE FROM supplier WHERE id_supplier='$id_supplier'";
	$query = mysqli_query($koneksi, $sql) or die (mysqli_error());
 
	if($query){
		echo "Data berhasil di Hapus!";
		header('Location: supplier.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}
 
	mysqli_close($koneksi);
?>