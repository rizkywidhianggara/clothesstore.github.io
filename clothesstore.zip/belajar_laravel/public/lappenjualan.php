<html>
<head>
	<title>Laporan Penjualan</title>
</head>
<body>
 
	<center>
 
		<h2>DATA LAPORAN PENJUALAN BARANG</h2>
		<h4>CLOTESTORE</h4>
 
	</center>
 
	<?php 
	include 'koneksi.php';
	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">Id Penjualan</th>
			<th>Tanggal Beli</th>
			<th>Nama Customer</th>
			<th>Nama Barang</th>
			<th>Kategori</th>
			<th>Harga jual</th>
			<th width="5%">Qty</th>
			<th>Total</th>
		</tr>
		<?php
    	include "koneksi.php";
        $sql = "SELECT penjualan.id_penjualan,penjualan.tgl_jual, customer.nama_customer, barang.nama_brg, penjualan.qty,penjualan.kategori, penjualan.harga_jual, penjualan.total, SUM(penjualan.total) as subtotal FROM penjualan JOIN customer ON penjualan.id_customer = customer.id_customer JOIN barang ON penjualan.id_barang=barang.id_barang;";
        $query = mysqli_query($koneksi, $sql) or die (mysqli_error());
        $id_penjualan = 1; // no. urut
        while($data = mysqli_fetch_array($query)){
    	?>
		<tr>
			<td><?php echo $id_penjualan++; ?></td>
      		<td><?php echo $data['tgl_jual']; ?></td>
      		<td><?php echo $data['nama_customer']; ?></td>
      		<td><?php echo $data['nama_brg']; ?></td>
      		<td><?php echo $data['kategori']; ?></td>
      		<td><?php echo number_format($data['harga_jual']); ?></td>
      		<td><?php echo $data['qty']; ?></td>
      		<td><?php echo number_format($data['total']); ?></td>
		</tr>
		<tr>
			<td colspan="7">Subtotal</td>
			<td><?php echo number_format($data['subtotal']); ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>