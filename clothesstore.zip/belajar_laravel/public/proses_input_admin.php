<?php
	include "koneksi.php";


    $username = $_POST['username'];
    $password = $_POST['password'];

	date_default_timezone_set("Asia/Jakarta");

	$tgl = date("Y:m:d");

	// query sql
	$sql = "INSERT INTO admin VALUES ('', '$username','$password')";
	$query = mysqli_query($koneksi, $sql);

	if($query){
		echo "Data berhasil di insert!";
		header('Location: index.php');
	} else {
		echo "Error :".$sql."<br>".mysqli_error($koneksi);
	}

	mysqli_close($koneksi);

?>
